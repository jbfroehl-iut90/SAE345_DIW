# SAE345_DIW
 
### Commande pour fetch sur pythonanywhere [dispo ici](https://jbfroehl.pythonanywhere.com/)  

La première fois :
```bash
git clone https://github.com/jbfroehl-iut90/SAE345_DIW.git
```

Ensuite pour update dans le terminal (attention à être dans le dossier)
```bash
git pull
```

Le repo est public donc pas besoin de token
